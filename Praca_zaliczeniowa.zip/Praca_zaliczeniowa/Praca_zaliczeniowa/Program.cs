﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Clubs
{
    internal class Program
    {
        public enum Role
        {
            Coach,
            Medic,
            Boss,
            Scout
        }
        public enum Position
        {
            Goalkeeper,
            LeftBack,
            RightBack,
            CentreBack,
            DefensiveMidfielder,
            Midfielder,
            OfensiveMidfielder,
            LeftMidfielder,
            RightMidfielder,
            LeftWinger,
            RightWinger,
            Striker
        }
        public class Club
        {
            public string Name { get; set; }
            public List<ClubMember> Members { get; set; }
            public Club(string name,List<ClubMember> members) 
            {
                Name = name;
                Members = members;
            }

        }
        public class ClubMember
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int Age { get; set; }
            public ClubMember(string firstName,string lastName,int age) 
            {
                FirstName = firstName;
                LastName = lastName;
                Age = age;
            }
        }
        public class Staff : ClubMember
        {
            public Role Role { get; set; }
            public Staff(Role role, string firstName, string lastName, int age) : base(firstName, lastName, age) {
                Role = role;
            }
        }
        public class Player : ClubMember
        {
            public Position Position { get; set; }
            public int Pace { get; set; }
            public int Shooting { get; set; }
            public int Passing { get; set; }
            public int Dribling { get; set; }
            public int Defense { get; set; }
            public int Physical { get; set; }
            public bool IsInjured { get; set; }
            public Player(Position position,int pace,int shooting,int passing,int dribling,int defense,int physical,bool isInjured, string firstName, string lastName, int age) : base(firstName, lastName, age)
            {
                Position = position;
                Pace = pace;
                Shooting = shooting;
                Passing = passing;
                Dribling = dribling;
                Defense = defense;
                Physical = physical;
                IsInjured = isInjured;
            }
        }
        public class Goalkeeper : Player
        {
            public int GoalkeeperStats { get; set; }
            public Goalkeeper(int goalkeeperStats,Position position, int pace, int shooting, int passing, int dribling, int defense, int physical, bool isInjured, string firstName, string lastName, int age) : base(position,pace,shooting,passing,dribling,defense,physical,isInjured,firstName,lastName,age)
            {
                GoalkeeperStats = goalkeeperStats;
            }
        }
        static void Main(string[] args)
        {

        }
    }
}